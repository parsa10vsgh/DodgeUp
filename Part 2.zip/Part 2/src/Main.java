import processing.core.PApplet;
import processing.core.PImage;

import java.util.ArrayList;

public class Main extends PApplet{

    public static PApplet processing;
    public static PImage background;

    public static ArrayList<Block> blocks = new ArrayList<>();
    public static int score = 0;
    public static int lives = 3;


    public static void main(String[] args) {

        PApplet.main("Main" ,args);

    }


    @Override
    public void setup() {
        processing = this;
        background = loadImage("background.jpg");

        Block.makeBlocks();
        Robot.loadImage();
    }

    @Override
    public void draw() {


        image(background, 0,0,400,700);

        Block.showBlock();
        Block.moveBlock();
        Robot.showImage();


        fill(0);
        rect(0, 600, 400, 100);
        fill(255, 238, 3);
        textSize(30);
        text("Score: " + score, 0, 640);
        fill(255, 3, 188);
        text("Lives: " + lives, 0, 670);


        score();
        if (Block.checkCrash()) {
            lives--;
        }

        if (lives == 0) {
            gameOver();
        }

        if (Main.blocks.size() == 0) {
            finish();
        }

    }

    @Override
    public void settings() {
        size(400, 700);
    }

    public static void score() {
        for (int i=0 ; i<Main.blocks.size() ; i++) {
            if (Main.blocks.get(i).getBlockY() >= 600) {
                score++;
                Main.blocks.remove(Main.blocks.get(i));
            }
        }
    }

    public void gameOver() {
        background(0);

        fill(255,0,0);
        textSize(60);
        text("Game Over", 60, 250);

        fill(255, 238, 3);
        textSize(35);
        text("Score: " + score, 140, 400);
        fill(255, 3, 188);
        text("Lives: " + lives, 145, 450);

        stop();

    }

    public void finish() {
        background(0);

        fill(16, 255, 3);
        textSize(60);
        text("Winner", 115, 250);

        fill(255, 238, 3);
        textSize(35);
        text("Score: " + score, 135, 400);
        fill(255, 3, 188);
        text("Lives: " + lives, 145, 450);

        stop();



    }

    @Override
    public void keyPressed() {
        if (key == CODED) {
            if (keyCode == 38 && Block.speed < 10) {
                Block.speed++;
            }
            else if (keyCode == 40 && Block.speed > 3) {
                Block.speed--;
            }
        }
    }
}