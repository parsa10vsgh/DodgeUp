import java.util.Random;

public class Block {


    public static int speed = 3;
    private static final int blockWidth = 20;
    private static final int blockHeight = 40;


    private final int blockX;
    private int blockY;
    private final int blockColorR;
    private final int blockColorG;
    private final int blockColorB;

    public Block(int blockX, int blockY, int blockColorR, int blockColorG, int blockColorB) {
        this.blockX = blockX;
        this.blockY = blockY;
        this.blockColorR = blockColorR;
        this.blockColorG = blockColorG;
        this.blockColorB = blockColorB;
    }

    public static void makeBlocks() {
        Random random = new Random();
        int speedY = -100;
        for (int i=0 ; i<10 ; i++) {
            Main.blocks.add(new Block(random.nextInt(30, 350), speedY, random.nextInt(253), random.nextInt(253), random.nextInt(253)));
            speedY -= 100;
            Main.blocks.add(new Block(random.nextInt(30, 350), speedY, random.nextInt(253), random.nextInt(253), random.nextInt(253)));
            speedY -= 100;
            Main.blocks.add(new Block(random.nextInt(30, 350), speedY, random.nextInt(253), random.nextInt(253), random.nextInt(253)));
            speedY -= 100;
            Main.blocks.add(new Block(random.nextInt(30, 350), speedY, random.nextInt(253), random.nextInt(253), random.nextInt(253)));
            speedY -= 100;
        }
    }

    public static void showBlock() {
        for (Block b: Main.blocks) {
            Main.processing.noStroke();
            Main.processing.fill(b.blockColorR, b.blockColorG, b.blockColorB);
            Main.processing.rect(b.blockX, b.blockY, Block.blockWidth, Block.blockHeight);
        }
    }

    public static void moveBlock() {

        for (Block b: Main.blocks) {
            b.blockY += speed;
        }
    }



    public static boolean checkCrash() {
        for (Block b: Main.blocks) {

            if (Main.processing.mouseX >= b.blockX && Main.processing.mouseX <= b.blockX + Block.blockWidth &&
                    545 >= b.blockY && 545 <= b.blockY + Block.blockHeight) {

                Main.blocks.remove(b);
                return true;
            }

            else if (Main.processing.mouseX+25 >= b.blockX && Main.processing.mouseX+25 <= b.blockX + Block.blockWidth &&
                    545 >= b.blockY && 545 <= b.blockY + Block.blockHeight) {

                Main.blocks.remove(b);
                return true;
            }

            else if (Main.processing.mouseX-25 >= b.blockX && Main.processing.mouseX-25 <= b.blockX+ Block.blockWidth &&
                    545 >= b.blockY && 545 <= b.blockY + Block.blockHeight) {

                Main.blocks.remove(b);
                return true;
            }

            else if (Main.processing.mouseX-25 >= b.blockX && Main.processing.mouseX-25 <= b.blockX + Block.blockWidth &&
                    590 >= b.blockY && 590 <= b.blockY + Block.blockHeight) {

                Main.blocks.remove(b);
                return true;
            }

            else if (Main.processing.mouseX+25 >= b.blockX && Main.processing.mouseX+25 <= b.blockX + Block.blockWidth &&
                    590 >= b.blockY && 590 <= b.blockY + Block.blockHeight) {

                Main.blocks.remove(b);
                return true;
            }

            else if (Main.processing.mouseX >= b.blockX && Main.processing.mouseX <= b.blockX + Block.blockWidth &&
                    625 >= b.blockY && 625 <= b.blockY + Block.blockHeight) {

                Main.blocks.remove(b);
                return true;
            }

        }


        return false;
    }

    public int getBlockY() {
        return blockY;
    }
}
