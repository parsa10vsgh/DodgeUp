import processing.core.PImage;

public class Robot {

    private static PImage image;

    public static void loadImage() {
        image = Main.processing.loadImage("robot.png");
    }

    public static void showImage() {
        Main.processing.image(image,Main.processing.mouseX - 25, 530, 55 , 75);
    }
}
